% Capstone Project 2020: Brain-Controlled Chess Playing Robot with Steady-State Visual Evoked Potential

%Last updated: 25/10/20

%Summary:
    %create tcpip connections
    %whileloop
        %cmdt1: piece select
            %flash all the pieces that have valid movements
            %wait for one to be chosen
            %go to cmdt2
        %cmdt2: movement select
            %flash all the possible movements
            %wait for one to be chosen
            %move it and set all the attributes accordingly
                %move piece
                %deal with killed piece
                %check king: castling
                %check pawn: firstMove and enPassant
                %update location in MATLAB
                %check pawn: promotion
    %print gameover

%Creative credit to I. Halen (https://github.com/IvanHalen86/Matlab-Unity-Communication)

%Notes
    % i = 8(board(i).location(1)-1) + board(i).location(2)
    % i = 8(pieces(i).location(1)-1) + pieces(i).location(2)

%First press play in Unity, then run MATLAB file
%Should initialise: MATLAB will send commands to Unity to display what is
%required
    
clear all
clc

%Set up TCP/IP connections between MATLAB and game objects in Unity
%Pieces
for i=1:1:32
    tcpipClient_p(i) = tcpip(sprintf('127.0.0.%d', i), 55000+i, 'NetworkRole', 'Client');
    set(tcpipClient_p(i),'Timeout',3);
end

%Board
for i=1:1:64
    tcpipClient_b(i) = tcpip(sprintf('127.0.1.%d', i), 55032+i, 'NetworkRole', 'Client');
    set(tcpipClient_b(i),'Timeout',3);
end

%Messages (1 for PawnPromotion, 4 for pawn promotion options and 1 for Game
%Over message in that order)
for i=1:1:6
    tcpipClient_m(i) = tcpip(sprintf('127.0.2.%d', i), 55096+i, 'NetworkRole', 'Client');
    set(tcpipClient_b(i),'Timeout',3);
end

%Initially hide the messages and promotion options: send -1 as frequency
for i=1:1:6
    fopen(tcpipClient_m(i));
    fwrite(tcpipClient_m(i), '-1');
    fclose(tcpipClient_m(i));
end

%Create bluetooth object
BT=Bluetooth('HC-06',1);

%Initialise variable 'game' that is 1 when the game is still in progress or
%0 when the game is over
game = 1;

%initialise the command type to 1, signifying piece selection.
%(1 for piece select, 2 for move location, COULD BE MORE)
cmd_t = 1;

%Randomly decide who will start first. p_turn=1 means player 1's turn,
%p_turn=2 means player 2's turn.
p_turn = 1 + round(rand);
    
%Declare and initialise an array of structs for each of the pieces,
%where at the start of the game the pieces are of type:
% [R Kn B Q K B Kn R P P P P P P P P R Kn B K Q B Kn R P P P P P P P P]
i=1;
%Player 1's pieces: location, flash frequency and player number
for r=1:1:2
    for c=1:1:8
        pieces(i).location = [r,c];
        pieces(i).freq = 0.00;
        pieces(i).player = 1;
        i=i+1;
    end
end
%Player 2's pieces: location, flash frequency and player number
for r=8:-1:7
    for c=8:-1:1
        pieces(i).location = [r,c];
        pieces(i).freq = 0.00;
        pieces(i).player = 2;
        i=i+1;
    end
end
    
%Add the piece type as a field in the struct and set the status for
%each as 'alive'. For special pieces (king, pawn and rook), add fields
%firstMove, enPassant and promoted for pawn, inCheck firstMove and
%inCheckmate for king, and firstMove for rook
for i=1:1:32
    if ((i==1)||(i==8)||(i==17)||(i==24)) % Rook
        pieces(i).piecetype = 'rook';
        pieces(i).firstMove = 'yes';
        
    elseif ((i==2)||(i==7)||(i==18)||(i==23)) % Knight
        pieces(i).piecetype = 'knight';
        
    elseif ((i==3)||(i==6)||(i==19)||(i==22)) % Bishop
        pieces(i).piecetype = 'bishop';
        
    elseif ((i==4)||(i==21)) %Queen
        pieces(i).piecetype = 'queen';
        
    elseif ((i==5)||(i==20)) %King
        pieces(i).piecetype = 'king';
        pieces(i).firstMove = 'yes';
        pieces(i).inCheck = 'no';
        pieces(i).inCheckmate = 'no';
        
    else % Pawn
        pieces(i).piecetype = 'pawn';
        pieces(i).firstMove = 'yes';
        pieces(i).enPassant = 'no';
        pieces(i).promotion = 0;
    end
    pieces(i).status = 'alive';
end

%Add board piece's flashing frequency and location
r=1;
c=1;
for i=1:1:64
    board(i).freq = 0.00;
    board(i).location = [r,c];
    c=c+1;
    if (c==9)
        %Reached end of board: +1 to r, and set c back to 1
        r=r+1;
        c=1;
    end
end 

%Create inCheck variable, which will be used for checking if a possible
%move will endanger the player's king ie put the player in check
inCheck=0;

%Create inCheckmate variable, which will be used to determine if the player
%is in checkmate
inCheckmate=0;

%Initialise two variables r_old and c_old which will store the piece
%location while king endangerment is being checked
r_old = 0;
c_old = 0;

%Initialise variable noValidMove which checks if there is any valid moves
%for the specified piece. Used during cmd_t=1
noValidMove = 1;

%Initialise variables i_pieceChosen and i_boardChosen which will record
%the index of the arrays pieces[] and board[], corresponding to the
%piece chosen to be moved and the board location chosen to be moved to
%respectively.
i_pieceChosen = 1;
i_boardChosen = 1;

%Declare and initialise variables allyPieceHere which checks if an ally
%piece is on top of the specified board location, and enemyPieceHere
%which checks if an enemy piece is on top of the location. Also a generic
%pieceHere variable to state if a piece is here or not
allyPieceHere = 0;
enemyPieceHere = 0;
pieceHere = 0;

%Declare variable to determine if castling is available
castlingAvailable = 0;

% SET VALUE FOR MAX AND MIN FREQUENCIES THAT CAN BE SENT
freq = 0; %Declare variable freq that will determine the frequency sent
freqMin = 5;
freqMax = 10;
numPossibleFrequencies = 27; %27 because that is the maximum number of different frequencies that can be sent
dfreq = (freqMax-freqMin)/numPossibleFrequencies;

%Declare variable freqReturned which is the frequency returned by Arduino
freqReturned = 0;

%The allowable error between the sent and returned frequencies
FREQERRMAX = 0.1;

freqPromoOptions = freqMax;
numPromoOptions = 4;
dfreqPromoOptions = (freqMax-freqMin)/numPromoOptions;

%DEBUGGING (added 2/9/20 2.26AM): count the number of errors in reading
numErrors = 0;

while(game==1)
    if (cmd_t==1) %cmd_t = 1: piece selection
        
        %Reset the frequency sent to be freqMax+dfreq: ie one iteration above the maximum
        freq = freqMax + dfreq;
        
        %20/10/20:
        %For every movement we make, check if the king will be in danger.
        %As soon as we can find a single move where he is not in danger, we
        %can set inCheckmate=0. After cycling through all moves, if no
        %options are found we set game=0 to indicate Game Over

        %New move: set inCheckmate = 1, as soon as there is even a single
        %movement that does not leave king endangered we set this back to 0
        inCheckmate = 1;
        
        %Check each piece to see if it has any legal moves. As soon as
        %there is one, we can continue onward
        for i=1:1:length(pieces)
            if (pieces(i).player==p_turn)&&(strcmp(pieces(i).status, 'alive')==1)
                %Set variable that claims there is no valid move found for this piece
                noValidMove = 1;
                
                if (strcmp(pieces(i).piecetype, 'rook')==1)||(strcmp(pieces(i).piecetype, 'rookP')==1) %Rook
                    cmdt1_lrdu
                elseif (strcmp(pieces(i).piecetype, 'knight')==1)||(strcmp(pieces(i).piecetype, 'knightP')==1) %Knight
                    %(-2,-1)
                    r = pieces(i).location(1) -1;
                    c = pieces(i).location(2) -2;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(-2,+1)
                    r = pieces(i).location(1) +1;
                    c = pieces(i).location(2) -2;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+2,+1)
                    r = pieces(i).location(1) +1;
                    c = pieces(i).location(2) +2;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+2,-1)
                    r = pieces(i).location(1) -1;
                    c = pieces(i).location(2) +2;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(-1,-2)
                    r = pieces(i).location(1) -2;
                    c = pieces(i).location(2) -1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(-1,+2)
                    r = pieces(i).location(1) +2;
                    c = pieces(i).location(2) -1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+1,+2)
                    r = pieces(i).location(1) + 2;
                    c = pieces(i).location(2) + 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+1,-2)
                    r = pieces(i).location(1) - 2;
                    c = pieces(i).location(2) + 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                elseif (strcmp(pieces(i).piecetype, 'bishop')==1)||(strcmp(pieces(i).piecetype, 'bishopP')==1) %Bishop
                    cmdt1_ldlururd
                elseif (strcmp(pieces(i).piecetype, 'queen')==1)||(strcmp(pieces(i).piecetype, 'queenP')==1) %Queen
                    cmdt1_lrdu
                    cmdt1_ldlururd
                elseif (strcmp(pieces(i).piecetype, 'king')==1) %King
                    %(-1,-1)
                    r = pieces(i).location(1) -1;
                    c = pieces(i).location(2) -1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(-1,0)
                    r = pieces(i).location(1);
                    c = pieces(i).location(2) -1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(-1,+1)
                    r = pieces(i).location(1) + 1;
                    c = pieces(i).location(2) - 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(0,-1)
                    r = pieces(i).location(1) -1;
                    c = pieces(i).location(2);
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(0,+1)
                    r = pieces(i).location(1)+1;
                    c = pieces(i).location(2);
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+1,+1)
                    r = pieces(i).location(1) + 1;
                    c = pieces(i).location(2) + 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+1,0)
                    r = pieces(i).location(1);
                    c = pieces(i).location(2) + 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                    
                    %(+1,-1)
                    r = pieces(i).location(1) - 1;
                    c = pieces(i).location(2) + 1;
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    
                    cmdt1_knightkingcheck
                else %Pawn
                    if (p_turn==1)                    
                        %Normal move
                        r = pieces(i).location(1) + 1;
                        c = pieces(i).location(2);
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn

                        %First move
                        if (strcmp(pieces(i).firstMove, 'yes')==1)
                            r = pieces(i).location(1) + 2;
                            c = pieces(i).location(2);
                            allyPieceHere = 0;
                            enemyPieceHere = 0;
                            cmdt1_pawn
                        end

                        %Left Kill
                        r = pieces(i).location(1) + 1;
                        c = pieces(i).location(2) - 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_kill
                        
                        %Right Kill
                        r = pieces(i).location(1) + 1;
                        c = pieces(i).location(2) + 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_kill
                        
                        %En Passant Kill: left
                        r = pieces(i).location(1);
                        c = pieces(i).location(2) - 1;
                        r_move = 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_enPassant
                        
                        %En Passant Kill: right
                        r = pieces(i).location(1);
                        c = pieces(i).location(2) + 1;
                        r_move = 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_enPassant
                    else
                        %Normal move
                        r = pieces(i).location(1) - 1;
                        c = pieces(i).location(2);
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn

                        %First move
                        if (strcmp(pieces(i).firstMove, 'yes')==1)
                            r = pieces(i).location(1) - 2;
                            c = pieces(i).location(2);
                            allyPieceHere = 0;
                            enemyPieceHere = 0;
                            cmdt1_pawn
                        end

                        %Left Kill
                        r = pieces(i).location(1) - 1;
                        c = pieces(i).location(2) + 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_kill
                        
                        %Right Kill
                        r = pieces(i).location(1) - 1;
                        c = pieces(i).location(2) - 1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_kill
                        
                        %En Passant Kill: left
                        r = pieces(i).location(1);
                        c = pieces(i).location(2) + 1;
                        r_move = -1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_enPassant
                        
                        %En Passant Kill: right
                        r = pieces(i).location(1);
                        c = pieces(i).location(2) - 1;
                        r_move = -1;
                        allyPieceHere = 0;
                        enemyPieceHere = 0;
                        cmdt1_pawn_enPassant
                    end
                end
                
                if (noValidMove==0)
                    %There is a valid move for this piece. So flash it
                    
                    freq = freq - dfreq;

                    pieces(i).freq = freq;
                    
                    move = append(num2str(pieces(i).freq), ',0,0');
                    if (strcmp(pieces(i).piecetype, 'pawn')==1)||(strcmp(pieces(i).piecetype, 'rookP')==1)||(strcmp(pieces(i).piecetype, 'knightP')==1)||(strcmp(pieces(i).piecetype, 'bishopP')==1)||(strcmp(pieces(i).piecetype, 'queenP')==1)
                        %Pawn: send frequency, movement and promoted status
                        move = append(move, ',', num2str(pieces(i).promotion));
                    end

                    %Parse to Unity
                    fopen(tcpipClient_p(i));
                    fwrite(tcpipClient_p(i), move);
                    fclose(tcpipClient_p(i));
                end
            end
        end
        
        %No valid move was found that could keep the king safe: we are in
        %checkmate
        if (inCheckmate==1)
            game = 0;
        end
        
        %Await frequency from arduino
        freqReturned = readFreq(BT)
        while ((freqReturned>(freqMax+dfreq))||(freqReturned<freqMin))
            numErrors = numErrors + 1;
            freqReturned = readFreq(BT) 
        end

        %Compare the returned frequency to determine the chosen piece
        for i=1:1:length(pieces)
            if (abs(pieces(i).freq - freqReturned)<=FREQERRMAX)&&(pieces(i).player==p_turn)
                %This piece has matching frequency and belongs to
                %the player, so this is the piece to move
                i_pieceChosen = i;
            end
        end

        %Stop flashing all those pieces that were flashing
        for i=1:1:length(pieces)
            %Set frequency to 0
            pieces(i).freq = 0.00;

            %Create message to be sent to Unity
            move = append(num2str(pieces(i).freq), ',0,0');
            if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'rookP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'knightP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'bishopP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'queenP')==1)
                move = append(move, ',', num2str(pieces(i_pieceChosen).promotion));
            end          

            %Parse to Unity: frequency and movement
            fopen(tcpipClient_p(i));
            fwrite(tcpipClient_p(i), move);
            fclose(tcpipClient_p(i));
        end

        %Set cmd_t = 2 to signal switch to next stage of movement
        cmd_t = 2;

    else %cmd_t = 2: movement location selection
         fprintf('rearched cmd2');
        
        %Reset the frequency sent to be freqMax+dfreq: ie one iteration above the maximum
        freq = freqMax + dfreq;
        
        if (strcmp(pieces(i_pieceChosen).piecetype, 'rook')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'rookP')==1) %Rook
            cmdt2_lrdu
        elseif (strcmp(pieces(i_pieceChosen).piecetype, 'knight')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'knightP')==1) % knight
            %(-2,-1)
            r = pieces(i_pieceChosen).location(1) -1;
            c = pieces(i_pieceChosen).location(2) -2;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(-2,+1)
            r = pieces(i_pieceChosen).location(1) +1;
            c = pieces(i_pieceChosen).location(2) -2;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+2,+1)
            r = pieces(i_pieceChosen).location(1) +1;
            c = pieces(i_pieceChosen).location(2) +2;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+2,-1)
            r = pieces(i_pieceChosen).location(1) -1;
            c = pieces(i_pieceChosen).location(2) +2;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(-1,-2)
            r = pieces(i_pieceChosen).location(1) -2;
            c = pieces(i_pieceChosen).location(2) -1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(-1,+2)
            r = pieces(i_pieceChosen).location(1) +2;
            c = pieces(i_pieceChosen).location(2) -1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+1,+2)
            r = pieces(i_pieceChosen).location(1) + 2;
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+1,-2)
            r = pieces(i_pieceChosen).location(1) - 2;
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

        elseif (strcmp(pieces(i_pieceChosen).piecetype, 'bishop')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'bishopP')==1) % bishop
            cmdt2_ldlururd
        elseif (strcmp(pieces(i_pieceChosen).piecetype, 'queen')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'queenP')==1) % queen
            cmdt2_lrdu
            cmdt2_ldlururd
        elseif (strcmp(pieces(i_pieceChosen).piecetype, 'king')==1) % king
            %(-1,-1)
            r = pieces(i_pieceChosen).location(1) - 1;
            c = pieces(i_pieceChosen).location(2) - 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(-1,0)
            r = pieces(i_pieceChosen).location(1);
            c = pieces(i_pieceChosen).location(2) - 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(-1,+1)
            r = pieces(i_pieceChosen).location(1) + 1;
            c = pieces(i_pieceChosen).location(2) - 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(0,-1)
            r = pieces(i_pieceChosen).location(1);
            c = pieces(i_pieceChosen).location(2) - 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(0,+1)
            r = pieces(i_pieceChosen).location(1);
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+1,+1)
            r = pieces(i_pieceChosen).location(1) + 1;
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+1,0)
            r = pieces(i_pieceChosen).location(1);
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;

            cmdt2_knightkingcheck

            %(+1,-1)
            r = pieces(i_pieceChosen).location(1) - 1;
            c = pieces(i_pieceChosen).location(2) + 1;
            allyPieceHere = 0;
            enemyPieceHere = 0;
            
            cmdt2_knightkingcheck
            
            %Castling
            if (strcmp(pieces(i_pieceChosen).firstMove, 'yes')==1) %king's first move
                r = pieces(i_pieceChosen).location(1);
                c = pieces(i_pieceChosen).location(2);
                %check for castles that have not made a first move yet
                for i=1:1:length(pieces)
                    if ((strcmp(pieces(i).piecetype, 'rook')==1)&&(strcmp(pieces(i).firstMove, 'yes')==1)&&(pieces(i).player==p_turn))
                        %rook has not made its first move and belongs to the player
                        
                        %now check if the spaces between the king and the rook are empty
                        
                        %Set castlingAvailable=1, to be changed if castling is unavailable
                        castlingAvailable = 1;
                        if (pieces(i).location(2)<pieces(i_pieceChosen).location(2))
                            %castle on the left
                            
                            %now check the spaces between
                            j=pieces(i_pieceChosen).location(2)-1;
                            while (j>pieces(i).location(2)) %the column is greater than the column of the rook
                                %Check pieces[] to see if any are here
                                for k=1:1:length(pieces)
                                    if ((pieces(k).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(k).location(2)==j))
                                        %piece is already here
                                        castlingAvailable=0;
                                        break
                                    end
                                end
                                j=j-1;
                            end
                            
                            %Castling can not occur through check. So check
                            %each hypothetical movement to see if the king
                            %will be in danger at any of these
                            if (castlingAvailable==1)
                                m=pieces(i_pieceChosen).location(2)-1;
                                c_old = pieces(i_pieceChosen).location(2);
                                while (m>pieces(i).location(2))
                                    %Move the king to this location and see
                                    %if any pieces can hurt him
                                    pieces(i_pieceChosen).location(2) = m;
                                    %Check for any enemies killing him
                                    inCheck = 0;
                                    for j=1:1:length(pieces)
                                        if (pieces(j).player~=p_turn)&&(strcmp(pieces(j).status, 'alive')==1)
                                            %Enemy piece that is alive: check if it can kill my king
                                            if (strcmp(pieces(j).type, 'rook')==1)||(strcmp(pieces(j).type, 'rookP')==1)
                                                %Left
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2-1;
                                                end
                                                %Right
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2+1;
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'knight')==1)||(strcmp(pieces(j).piecetype, 'knightP')==1) %Knight
                                                %(-2,-1)
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-2,+1)
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+2,+1)
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+2,-1)
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-1,-2)
                                                r2 = pieces(j).location(1) - 2;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-1,+2)
                                                r2 = pieces(j).location(1) + 2;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+1,+2)
                                                r2 = pieces(j).location(1) + 2;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+1,-2)
                                                r2 = pieces(j).location(1) - 2;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'bishop')==1)||(strcmp(pieces(j).piecetype, 'bishopP')==1) %Bishop
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2-1;
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2-1;
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2+1;
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'queen')==1)||(strcmp(pieces(j).piecetype, 'queenP')==1) %Queen
                                                %Left
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2-1;
                                                end
                                                %Right
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2+1;
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                end
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2-1;
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2-1;
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2+1;
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'king')==1) %King
                                                %Left
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                            else %Pawn
                                                if (p_turn==1)
                                                    %Left kill
                                                    r2 = pieces(j).location(1) - 1;
                                                    c2 = pieces(j).location(2) + 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                    %Right kill
                                                    r2 = pieces(j).location(1) - 1;
                                                    c2 = pieces(j).location(2) - 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                else
                                                    %Left kill
                                                    r2 = pieces(j).location(1) + 1;
                                                    c2 = pieces(j).location(2) - 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                    %Right kill
                                                    r2 = pieces(j).location(1) + 1;
                                                    c2 = pieces(j).location(2) + 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king: castling is unavailable
                                                                    castlingAvailable=0;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                    
                                    m=m-1;
                                end
                                %Now reset the king's position after testing
                                pieces(i_pieceChosen).location(2) = c_old;
                            end
                            
                            if (castlingAvailable==1)
                                %Highlight the available square: 2 spots to the left
                                
                                freq = freq - dfreq;
                                
                                %Set the board's frequency to the current iteration frequency
                                board(8*(r-1)+c-2).freq = freq;
                                
                                %Parse to Unity: flash board
                                fopen(tcpipClient_b(8*(r-1)+c-2));
                                fwrite(tcpipClient_b(8*(r-1)+c-2), num2str(freq));
                                fclose(tcpipClient_b(8*(r-1)+c-2));
                               
                            end
                            
                        else
                            %castle on the right
                            
                            %now check the spaces between
                            j=pieces(i_pieceChosen).location(2)+1;
                            while (j<pieces(i).location(2)) %the column is greater than the column of the rook
                                %Check pieces[] to see if any are here
                                for k=1:1:length(pieces)
                                    if ((pieces(k).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(k).location(2)==j))
                                        %piece is already here
                                        castlingAvailable=0;
                                        break
                                    end
                                end
                                j=j+1;
                            end
                            
                            %Castling can not occur through check. So check
                            %each hypothetical movement to see if the king
                            %will be in danger at any of these
                            if (castlingAvailable==1)
                                m=pieces(i_pieceChosen).location(2)+1;
                                c_old = pieces(i_pieceChosen).location(2);
                                while (m>pieces(i).location(2))
                                    %Move the king to this location and see
                                    %if any pieces can hurt him
                                    pieces(i_pieceChosen).location(2) = m;
                                    %Check for any enemies killing him
                                    inCheck = 0;
                                    for j=1:1:length(pieces)
                                        if (pieces(j).player~=p_turn)&&(strcmp(pieces(j).status, 'alive')==1)
                                            %Enemy piece that is alive: check if it can kill my king
                                            if (strcmp(pieces(j).type, 'rook')==1)||(strcmp(pieces(j).type, 'rookP')==1)
                                                %Left
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2-1;
                                                end
                                                %Right
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2+1;
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'knight')==1)||(strcmp(pieces(j).piecetype, 'knightP')==1) %Knight
                                                %(-2,-1)
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-2,+1)
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+2,+1)
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+2,-1)
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 2;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-1,-2)
                                                r2 = pieces(j).location(1) - 2;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(-1,+2)
                                                r2 = pieces(j).location(1) + 2;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+1,+2)
                                                r2 = pieces(j).location(1) + 2;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %(+1,-2)
                                                r2 = pieces(j).location(1) - 2;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'bishop')==1)||(strcmp(pieces(j).piecetype, 'bishopP')==1) %Bishop
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2-1;
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2-1;
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2+1;
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'queen')==1)||(strcmp(pieces(j).piecetype, 'queenP')==1) %Queen
                                                %Left
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2-1;
                                                end
                                                %Right
                                                r2 = pieces(j).location(1);
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    c2 = c2+1;
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2);
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                end
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2-1;
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2-1;
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2+1;
                                                    c2 = c2+1;
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any allies are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                    r2 = r2-1;
                                                    c2 = c2+1;
                                                end
                                            elseif (strcmp(pieces(j).piecetype, 'king')==1) %King
                                                %Left
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Down
                                                r2 = pieces(j).location(1) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Up
                                                r2 = pieces(j).location(1) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Left,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Left,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) - 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right,Up
                                                r2 = pieces(j).location(1) + 1;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                                %Right,Down
                                                r2 = pieces(j).location(1) - 1;
                                                c2 = pieces(j).location(2) + 1;
                                                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                    %check each piece to see if any pieces are atop
                                                    for k=1:1:length(pieces)
                                                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                %This enemy piece can kill the king
                                                                inCheck=1;
                                                            end
                                                            break
                                                        end
                                                    end
                                                end
                                            else %Pawn
                                                if (p_turn==1)
                                                    %Left kill
                                                    r2 = pieces(j).location(1) - 1;
                                                    c2 = pieces(j).location(2) + 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                    %Right kill
                                                    r2 = pieces(j).location(1) - 1;
                                                    c2 = pieces(j).location(2) - 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                else
                                                    %Left kill
                                                    r2 = pieces(j).location(1) + 1;
                                                    c2 = pieces(j).location(2) - 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king
                                                                    inCheck=1;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                    %Right kill
                                                    r2 = pieces(j).location(1) + 1;
                                                    c2 = pieces(j).location(2) + 1;
                                                    if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                                                        %check each piece to see if any pieces are atop
                                                        for k=1:1:length(pieces)
                                                            if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                                                                if (pieces(k).player==p_turn)&&(strcmp(pieces(k).type, 'king')==1)
                                                                    %This enemy piece can kill the king: castling is unavailable
                                                                    castlingAvailable=0;
                                                                end
                                                                break
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                    
                                    m=m+1;
                                end
                                pieces(i_pieceChosen).location(2) = c_old;
                                %Now reset the king's position after testing
                            end
                            
                            if (castlingAvailable==1)                                
                                %Highlight the available square: 2 spots to the right
                                
                                freq = freq - dfreq;
                                
                                %Set the board's frequency to the current iteration frequency
                                board(8*(r-1)+c+2).freq = freq;

                                %Parse to Unity: flash board
                                fopen(tcpipClient_b(8*(r-1)+c+2));
                                fwrite(tcpipClient_b(8*(r-1)+c+2), num2str(freq));
                                fclose(tcpipClient_b(8*(r-1)+c+2));
                                
                            end
                        end
                    end
                end
            end

        else %Pawn
            if (p_turn==1)                    
                %Normal move
                r = pieces(i_pieceChosen).location(1) + 1;
                c = pieces(i_pieceChosen).location(2);
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn

                %First move
                if (strcmp(pieces(i_pieceChosen).firstMove, 'yes')==1)
                    r = pieces(i_pieceChosen).location(1) + 2;
                    c = pieces(i_pieceChosen).location(2);
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    cmdt2_pawn
                end

                %Left Kill
                r = pieces(i_pieceChosen).location(1) + 1;
                c = pieces(i_pieceChosen).location(2) - 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_kill

                %Right Kill
                r = pieces(i_pieceChosen).location(1) + 1;
                c = pieces(i_pieceChosen).location(2) + 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_kill

                %En Passant Kill: left
                r = pieces(i_pieceChosen).location(1);
                c = pieces(i_pieceChosen).location(2) - 1;
                r_move = 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_enPassant

                %En Passant Kill: right
                r = pieces(i_pieceChosen).location(1);
                c = pieces(i_pieceChosen).location(2) + 1;
                r_move = 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_enPassant
            else
                %Normal move
                r = pieces(i_pieceChosen).location(1) - 1;
                c = pieces(i_pieceChosen).location(2);
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn

                %First move
                if (strcmp(pieces(i_pieceChosen).firstMove, 'yes')==1)
                    r = pieces(i_pieceChosen).location(1) - 2;
                    c = pieces(i_pieceChosen).location(2);
                    allyPieceHere = 0;
                    enemyPieceHere = 0;
                    cmdt2_pawn
                end

                %Left Kill
                r = pieces(i_pieceChosen).location(1) - 1;
                c = pieces(i_pieceChosen).location(2) + 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_kill

                %Right Kill
                r = pieces(i_pieceChosen).location(1) - 1;
                c = pieces(i_pieceChosen).location(2) - 1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_kill

                %En Passant Kill: left
                r = pieces(i_pieceChosen).location(1);
                c = pieces(i_pieceChosen).location(2) + 1;
                r_move = -1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_enPassant

                %En Passant Kill: right
                r = pieces(i_pieceChosen).location(1);
                c = pieces(i_pieceChosen).location(2) - 1;
                r_move = -1;
                allyPieceHere = 0;
                enemyPieceHere = 0;
                cmdt2_pawn_enPassant
            end
        end
        
        % 2ND PHASE OF CMD_T=2: MOVE THE STUFF

        %await returned frequency from photodiode-arduino-simulink system
        freqReturned = readFreq(BT)
        while ((freqReturned>(freqMax+dfreq))||(freqReturned<freqMin))
            numErrors = numErrors + 1;
            freqReturned = readFreq(BT)
        end

        %Take the signal and cross reference with the current
        %frequencies from previous command
        for i=1:1:length(board)
            if (abs(board(i).freq - freqReturned)<=FREQERRMAX)
                %This board location frequency matches, so this is the correct location
                i_boardChosen = i;
            end
        end
        
        %Stop blinking all board locations
        for i=1:1:length(board)
            if (board(i).freq~=0)
                board(i).freq = 0;
                fopen(tcpipClient_b(i));
                fwrite(tcpipClient_b(i), num2str(board(i).freq));
                fclose(tcpipClient_b(i));
            end
        end

        %Send the movement to Unity:
        
        %Create the command to be sent to the piece
        move_vertical = 1.2*(board(i_boardChosen).location(1) - pieces(i_pieceChosen).location(1)); %HARDCODED HERE
        move_horizontal = 1.2*(board(i_boardChosen).location(2) - pieces(i_pieceChosen).location(2));
        move = strcat(num2str(move_horizontal), ',');
        move = strcat(move, num2str(move_vertical));
        move = append(num2str(pieces(i_pieceChosen).freq), ',', move);
        if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'rookP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'knightP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'bishopP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'queenP')==1)
            %Pawn: send frequency, movement and promoted status
            move = append(move, ',', num2str(pieces(i_pieceChosen).promotion));
        end
        
        fopen(tcpipClient_p(i_pieceChosen));
        fwrite(tcpipClient_p(i_pieceChosen), move);
        fclose(tcpipClient_p(i_pieceChosen));
        
%         %Immediately send another string to command a stop
%         move = append(num2str(pieces(i_pieceChosen).freq), ',0,0');
%         if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'rookP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'knightP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'bishopP')==1)||(strcmp(pieces(i_pieceChosen).piecetype, 'queenP')==1)
%             %Pawn: send frequency, movement and promoted status
%             move = append(move, ',', num2str(pieces(i_pieceChosen).promotion));
%         end
%         
%         fopen(tcpipClient_p(i_pieceChosen));
%         fwrite(tcpipClient_p(i_pieceChosen), move);
%         fclose(tcpipClient_p(i_pieceChosen));
%         fprintf('send movement');
        
        %Deal with killed piece: move to [0,0] and parse movement to Unity.
        %Also send the frequency as -1 which will cause it to not show
        %anymore
        for i=1:1:length(pieces)
            if (pieces(i).location==board(i_boardChosen).location)
                %this piece has been killed
                pieces(i).status = 'dead';
                pieces(i).freq = -1;
                
                %Send the movement to Unity:
                %Create the movement string 'X,Y' to move to [0,0]
                move_vertical = 1.2*(0 - pieces(i).location(1)); %HARDCODED HERE TOO
                move_horizontal = 1.2*(0 - pieces(i).location(2));
                move = strcat(num2str(move_horizontal), ',');
                move = strcat(move, num2str(move_vertical));
                move = append(num2str(pieces(i).freq), ',', move);
                
                %if pawn
                if (strcmp(pieces(i).piecetype, 'pawn')==1)||(strcmp(pieces(i).piecetype, 'rookP')==1)||(strcmp(pieces(i).piecetype, 'knightP')==1)||(strcmp(pieces(i).piecetype, 'bishopP')==1)||(strcmp(pieces(i).piecetype, 'queenP')==1)
                    move = append(move, ',', num2str(pieces(i).promotion));
                end
                
                fopen(tcpipClient_p(i));
                fwrite(tcpipClient_p(i), move);
                fclose(tcpipClient_p(i));
                
%                 %Immediately send another string to command a stop
%                 move = append(num2str(pieces(i).freq), ',0,0');
%                 if (strcmp(pieces(i).piecetype, 'pawn')==1)||(strcmp(pieces(i).piecetype, 'rookP')==1)||(strcmp(pieces(i).piecetype, 'knightP')==1)||(strcmp(pieces(i).piecetype, 'bishopP')==1)||(strcmp(pieces(i).piecetype, 'queenP')==1)
%                     %Pawn: send frequency, movement and promoted status
%                     move = append(move, ',', num2str(pieces(i).promotion));
%                 end
%                 
%                 fopen(tcpipClient_p(i));
%                 fwrite(tcpipClient_p(i), move);
%                 fclose(tcpipClient_p(i));
                
                pieces(i).location = [0,0];
                
                break
            end
        end
        
        %Deal with pawn killed by en Passant move
        if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)
            %piece chosen is pawn    
            if (p_turn==1)
                if (pieces(i_pieceChosen).location(1)==board(i_boardChosen).location(1)-1)
                    if (pieces(i_pieceChosen).location(2)==board(i_boardChosen).location(2)+1)
                        %Left diagonal move ie kill
                        for i=1:1:length(pieces)
                           if (pieces(i).player~=p_turn)&&(pieces(i).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(i).location(2)==pieces(i_pieceChosen).location(2)-1)
                               if (strcmp(pieces(i).type, 'pawn')==1)&&(strcmp(pieces(i).enPassant, 'yes')==1)
                                   %An en Passant kill was made. So remove
                                   %this piece
                                   pieces(i).status = 'dead';
                                   pieces(i).freq = -1;
                                   
                                   %Send the movement to Unity:
                                   %Create the movement string 'X,Y' to move to [0,0]
                                   move_vertical = 1.2*(0 - pieces(i).location(1)); %HARDCODED HERE TOO
                                   move_horizontal = 1.2*(0 - pieces(i).location(2));
                                   move = strcat(num2str(move_horizontal), ',');
                                   move = strcat(move, num2str(move_vertical));
                                   move = append(num2str(pieces(i).freq), ',', move);
                                   move = append(move, ',', num2str(pieces(i).promotion));

                                   fopen(tcpipClient_p(i));
                                   fwrite(tcpipClient_p(i), move);
                                   fclose(tcpipClient_p(i));
                                   
%                                    %Immediately send another string to command a stop
%                                    move = append(num2str(pieces(i).freq), ',0,0');
%                                    move = append(move, ',', num2str(pieces(i).promotion));
%                                    
%                                    fopen(tcpipClient_p(i));
%                                    fwrite(tcpipClient_p(i), move);
%                                    fclose(tcpipClient_p(i));
%                                    
%                                    pieces(i).location = [0,0];
                               end
                           end
                        end
                    elseif (pieces(i_pieceChosen).location(2)==board(i_boardChosen).location(2)-1)
                        %Right diagonal move ie kill
                        for i=1:1:length(pieces)
                           if (pieces(i).player~=p_turn)&&(pieces(i).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(i).location(2)==pieces(i_pieceChosen).location(2)+1)
                               if (strcmp(pieces(i).type, 'pawn')==1)&&(strcmp(pieces(i).enPassant, 'yes')==1)
                                   %An en Passant kill was made. So remove
                                   %this piece
                                   pieces(i).status = 'dead';
                                   pieces(i).freq = -1;
                                   
                                   %Send the movement to Unity:
                                   %Create the movement string 'X,Y' to move to [0,0]
                                   move_vertical = 1.2*(0 - pieces(i).location(1)); %HARDCODED HERE TOO
                                   move_horizontal = 1.2*(0 - pieces(i).location(2));
                                   move = strcat(num2str(move_horizontal), ',');
                                   move = strcat(move, num2str(move_vertical));
                                   move = append(num2str(pieces(i).freq), ',', move);
                                   move = append(move, ',', num2str(pieces(i).promotion));

                                   fopen(tcpipClient_p(i));
                                   fwrite(tcpipClient_p(i), move);
                                   fclose(tcpipClient_p(i));
                                   
%                                    %Immediately send another string to command a stop
%                                    move = append(num2str(pieces(i).freq), ',0,0');
%                                    move = append(move, ',', num2str(pieces(i).promotion));
%                                    
%                                    fopen(tcpipClient_p(i));
%                                    fwrite(tcpipClient_p(i), move);
%                                    fclose(tcpipClient_p(i));
%                                    
%                                    pieces(i).location = [0,0];
                               end
                           end
                        end
                    end
                end
            else
                if (pieces(i_pieceChosen).location(1)==board(i_boardChosen).location(1)+1)
                    if (pieces(i_pieceChosen).location(2)==board(i_boardChosen).location(2)-1)
                        %Left diagonal move ie kill
                        for i=1:1:length(pieces)
                           if (pieces(i).player~=p_turn)&&(pieces(i).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(i).location(2)==pieces(i_pieceChosen).location(2)+1)
                               if (strcmp(pieces(i).type, 'pawn')==1)&&(strcmp(pieces(i).enPassant, 'yes')==1)
                                   %An en Passant kill was made. So remove
                                   %this piece
                                   pieces(i).status = 'dead';
                                   pieces(i).freq = -1;
                                   
                                   %Send the movement to Unity:
                                   %Create the movement string 'X,Y' to move to [0,0]
                                   move_vertical = 1.2*(0 - pieces(i).location(1)); %HARDCODED HERE TOO
                                   move_horizontal = 1.2*(0 - pieces(i).location(2));
                                   move = strcat(num2str(move_horizontal), ',');
                                   move = strcat(move, num2str(move_vertical));
                                   move = append(num2str(pieces(i).freq), ',', move);
                                   move = append(move, ',', num2str(pieces(i).promotion));

                                   fopen(tcpipClient_p(i));
                                   fwrite(tcpipClient_p(i), move);
                                   fclose(tcpipClient_p(i));
                                   
%                                    %Immediately send another string to command a stop
%                                    move = append(num2str(pieces(i).freq), ',0,0');
%                                    move = append(move, ',', num2str(pieces(i).promotion));
%                                    
%                                    fopen(tcpipClient_p(i));
%                                    fwrite(tcpipClient_p(i), move);
%                                    fclose(tcpipClient_p(i));
%                                    
%                                    pieces(i).location = [0,0];
                               end
                           end
                        end
                    elseif (pieces(i_pieceChosen).location(2)==board(i_boardChosen).location(2)+1)
                        %Right diagonal move ie kill
                        for i=1:1:length(pieces)
                           if (pieces(i).player~=p_turn)&&(pieces(i).location(1)==pieces(i_pieceChosen).location(1))&&(pieces(i).location(2)==pieces(i_pieceChosen).location(2)-1)
                               if (strcmp(pieces(i).type, 'pawn')==1)&&(strcmp(pieces(i).enPassant, 'yes')==1)
                                   %An en Passant kill was made. So remove
                                   %this piece
                                   pieces(i).status = 'dead';
                                   pieces(i).freq = -1;
                                   
                                   %Send the movement to Unity:
                                   %Create the movement string 'X,Y' to move to [0,0]
                                   move_vertical = 1.2*(0 - pieces(i).location(1)); %HARDCODED HERE TOO
                                   move_horizontal = 1.2*(0 - pieces(i).location(2));
                                   move = strcat(num2str(move_horizontal), ',');
                                   move = strcat(move, num2str(move_vertical));
                                   move = append(num2str(pieces(i).freq), ',', move);
                                   move = append(move, ',', num2str(pieces(i).promotion));

                                   fopen(tcpipClient_p(i));
                                   fwrite(tcpipClient_p(i), move);
                                   fclose(tcpipClient_p(i));
                                   
%                                    %Immediately send another string to command a stop
%                                    move = append(num2str(pieces(i).freq), ',0,0');
%                                    move = append(move, ',', num2str(pieces(i).promotion));
%                                    
%                                    fopen(tcpipClient_p(i));
%                                    fwrite(tcpipClient_p(i), move);
%                                    fclose(tcpipClient_p(i));
%                                    
%                                    pieces(i).location = [0,0];
                               end
                           end
                        end
                    end
                end
            end
        end
        
        %Castling: check if castling occurred
        if (strcmp(pieces(i_pieceChosen).piecetype, 'king')==1)&&(abs(pieces(i_pieceChosen).location(2)-board(i_boardChosen).location(2))>1)
            %king that moved 2 spaces: hence castling was chosen
            if (board(i_boardChosen).location(2)<pieces(i_pieceChosen).location(2))
                %king moved left, so rook move right
                for i=1:1:length(pieces)
                    if ((strcmp(pieces(i).piecetype, 'rook')==1)&&(pieces(i).player==p_turn)&&(pieces(i).location(2)==1))
                        %rook on the left side of the board that belongs to the player, so move it 3 spaces to the right
                        
                        move = '0,3.6,0';
                        fopen(tcpipClient_p(i));
                        fwrite(tcpipClient_p(i), move);
                        fclose(tcpipClient_p(i));
%                         move = '0,0,0';
%                         fopen(tcpipClient_p(i));
%                         fwrite(tcpipClient_p(i), move);
%                         fclose(tcpipClient_p(i));
                        
                        %update in MATLAB
                        pieces(i).location(2) = pieces(i).location(2)+3;

                        break
                    end
                end
            else
                %king moved right, so rook move left
                for i=1:1:length(pieces)
                    if ((strcmp(pieces(i).piecetype, 'rook')==1)&&(pieces(i).player==p_turn)&&(pieces(i).location(2)==8))
                        %rook on the right side of the board that belongs to the player, so move it 2 spaces to the left
                        
                        move = '0,-2.4,0';
                        fopen(tcpipClient_p(i));
                        fwrite(tcpipClient_p(i), move);
                        fclose(tcpipClient_p(i));
%                         move = '0,0,0';
%                         fopen(tcpipClient_p(i));
%                         fwrite(tcpipClient_p(i), move);
%                         fclose(tcpipClient_p(i));
                        
                        %update in MATLAB
                        pieces(i).location(2) = pieces(i).location(2)-2;

                        break
                    end
                end
            end
        end
        
        %Change any previous en Passant to 'No'. Set all to 'No' and if the
        %last move set the pawn to en Passant, the next section will set it
        %back to 'Yes'.
        for i=1:1:length(pieces)
            if (strcmp(pieces(i).piecetype, 'pawn')==1)&&(strcmp(pieces(i).enPassant, 'yes')==1)
                pieces(i).enPassant = 'no';
            end
        end
        
        %If pawn moved, check:
            %if first move made, set firstMove = 'No'
            %if first move made and moved 2 spaces, set enPassant = 'Yes'
        if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)
            if (strcmp(pieces(i_pieceChosen).firstMove, 'yes')==1)
                %pawn that just made its first move
                pieces(i_pieceChosen).firstMove = 'no';
            end
            
            if (p_turn==1)
                if ((board(i_boardChosen).location(1)==pieces(i_pieceChosen).location(1) + 2)&&(board(i_boardChosen).location(2)==pieces(i_pieceChosen).location(2)))
                    %Player 1: first move and moved 2 spaces up
                    pieces(i_pieceChosen).enPassant = 'yes';
                end
            else
                if ((board(i_boardChosen).location(1)==pieces(i_pieceChosen).location(1) - 2)&&(board(i_boardChosen).location(2)==pieces(i_pieceChosen).location(2)))
                    %Player 2: first move and moved 2 spaces down
                    pieces(i_pieceChosen).enPassant = 'yes';
                end
            end
        end
        
        %Update moved piece's location
        pieces(i_pieceChosen).location = board(i_boardChosen).location;
        
        %Pawn Promotion
        if (strcmp(pieces(i_pieceChosen).piecetype, 'pawn')==1)
            if (((p_turn==1)&&(pieces(i_pieceChosen).location(1)==8))||((p_turn==2)&&(pieces(i_pieceChosen).location(1)==1)))
                %Player 1 pawn reached 8th row or Player 2 pawn reached 1st row
                
                freqPromoOptions = freqMax + dfreqPromoOptions;

                %Display the Promotion message box
                fopen(tcpipClient_m(1));
                fwrite(tcpipClient_m(1), '1');
                fclose(tcpipClient_m(1));

                %Show options at decided frequencies
                for i=2:1:5

                    freqPromoOptions = freqPromoOptions - dfreqPromoOptions;

                    %Parse to Unity
                    fopen(tcpipClient_m(i));
                    fwrite(tcpipClient_m(i), num2str(freqPromoOptions));
                    fclose(tcpipClient_m(i));
                end

                %Read the returned promotion option
                freqPromoOptionsReturned = readFreq(BT);
                while ((freqPromoOptionsReturned>(freqMax+dfreqPromoOptions))||(freqPromoOptionsReturned<freqMin))
                    numErrors = numErrors + 1;
                    freqPromoOptionsReturned = readFreq(BT);
                end

                %Pawn Promotion: 0 for pawn, 1 for queen, 2 for bishop, 3 for knight, 4 for rook                
                if (abs(freqPromoOptionsReturned - (freqMax-dfreqPromoOptions))<=FREQERRMAX)
                    %First iteration: queen
                    pieces(i_pieceChosen).piecetype = 'queenP';
                    pieces(i_pieceChosen).promotion = 1;
                elseif (abs(freqPromoOptionsReturned - (freqMax-2*dfreqPromoOptions))<=FREQERRMAX)
                    %Second iteration: bishop
                    pieces(i_pieceChosen).piecetype = 'bishopP';
                    pieces(i_pieceChosen).promotion = 2;
                elseif (abs(freqPromoOptionsReturned - (freqMax-3*dfreqPromoOptions))<=FREQERRMAX)
                    %Third iteration: knight
                    pieces(i_pieceChosen).piecetype = 'knightP';
                    pieces(i_pieceChosen).promotion = 3;
                else %May want to relook at this later for error checking
                    %Fourth iteration: rook
                    pieces(i_pieceChosen).piecetype = 'rookP';
                    pieces(i_pieceChosen).promotion = 4;
                end

                %close the box and options: send -1 as frequency
                for i=1:1:5
                    fopen(tcpipClient_m(i));
                    fwrite(tcpipClient_m(i), '-1');
                    fclose(tcpipClient_m(i));
                end

                %Change sprite of pawn
                move = append(num2str(pieces(i_pieceChosen).freq), ',0,0,', num2str(pieces(i_pieceChosen).promotion)); 
                fopen(tcpipClient_p(i_pieceChosen));
                fwrite(tcpipClient_p(i_pieceChosen), move);
                fclose(tcpipClient_p(i_pieceChosen));
            end
        end
        
        %End player's turn: change to other player's turn
        if (p_turn==1)
            %Was player 1's turn, so switch to player 2's turn
            p_turn = 2;
        else
            %Was player 2's turn, so switch to player 1's turn
            p_turn = 1;
        end
        
        cmd_t=1;
        
    end
end

%game has ended: show the "Game Over" message
fopen(tcpipClient_m(6));
fwrite(tcpipClient_m(6), '1');
fclose(tcpipClient_m(6));

%Print the number of errors
fprintf("Number of errors: %d", numErrors);

% NOTE TO SELF

%actually you will only ever have a maximum of 27 frequencies to choose
%from. Since pieces will only flash up to 16 at a time, and movement
%location options will only have up to 27 because vert,hor,diag+,diag-.
    
%Layers: GameOver, PromotionOutline, PromotionOptions, Pieces, BoardOutline, BoardSquares (6)
%In Unity, to save time Default is BoardSquares

%Pieces have attributes:
    %location, freq, player, piecetype, inCheck, inCheckmate, firstMove, enPassant, promoted, status

%Message to pieces should be:
    %-if normal piece:
        %flashfreq,moveHorizontal,moveVertical
    %-if pawn:
        %flashfreq,moveHorizontal,moveVertical,promotion
    
    %(if dead, send flashfreq=-1)
        

    % Extracted from Code_Moving_Cylinder_with_arrows.m
    
%     % open the port for the client
%     fopen(tcpipClient);
%     % pass the matrix "move" into the client (unity)
%     fwrite(tcpipClient,move);
%     % close the client
%     fclose(tcpipClient);    

%MOVES TO BE DONE IN INCREMENTS OF 1.2: moves exactly 1 space up/across

%REMEMBER: SEND MOVEMENT, THEN SEND 0 MOVEMENT IMMEDIATELY AFTER. OTHERWISE
%THE PIECE KEEPS FLYING UPWARD

%Pawn Promotion: 0 for pawn, 1 for queen, 2 for bishop, 3 for knight, 4 for rook

%location is [r,c]

%Added 29/07:
%Check Checkmate checker:
%game = checkForCheck();
%checkForCheck()
%Inputs: pieces[], p_turn
%Outputs: 'notCheck', 'inCheck' or 'inCheckmate' (string)
%Description:
%Basically this function should take in the pieces[] array and the p_turn
%variable. It will look at the player's king and get the location. It will
%then loop through the enemy's pieces to determine if any of the pieces can
%move directly onto the king's location. If any can, then the king is in
%check. It will then loop through the (up to 8) locations the king can move
%to and check if any enemy pieces can land on these; as soon as there is a
%move where none of the enemy's pieces can land, the king is deemed
%'inCheck'. If there are none, the king is inCheckmate and thus the game is
%over. If there are no enemy pieces that can move to the king's location,
%then checkForCheck() returns 'notCheck' and the game proceeds as usual.

%You can only be in check or checkmate if it is your turn. ie check for
%check/checkmate at the start of your turn ie cmd_t=1

%Search for possibility of movement:
%May be faster for stage 1 to simply determine if there is at least 1
%possible point to move to and return 1 or 0 depending on answer. If there
%is a possible place to move, change variable to 1 and break the loop, then
%return this. Repeat this for each piece; for each piece if there is a
%possible move then we flash it. If not, do not flash it.
%Function should be: searchPossibleMove(pieces[])


%Need 2 functions for check/checkmate checking:
%1. function to check if the king is currently in check/checkmate at the
%beginning of my turn, ie cmd_t=1 to see if my king is in danger
%str checkString = checkForCheck()

%2. function to determine if the move I plan to make will endanger my king
%str endangerString = checkEndanger()
%Explanation:
%Step1: Take in the current locations of the pieces, the selected piece and the proposed movement location.
%Step2: Save the old location, then try moving the selected piece to the proposed location
%Step3: run the checkForCheck() function to determine if my king will be in danger
%Step4: record whether or not the king will be in danger. If he will be,
%this piece and movement combination cannot be completed and the chosen
%location should not be flashed.
%Step5: replace the piece back to the old location and continue iterating
%through the possible locations for the piece to be moved to.

%30/07: pawn normal move/first move fixed

%pawns that are promoted are still taking in 4 inputs. so need to make a
%new type 'rookP', 'knightP', 'bishopP', 'queenP'

% readFreq(): returns a double or float

%UPDATE 30/07: FULLY UPDATED EXCEPT FOR THE TIMING OF READFREQ() FUNCTION,
%AND CHECK/CHECKMATE CHECKING. NOW IN THE PROCESS OF DEBUGGING (1.42PM)

%Update 13/09: Added checking for cmd_t=1 to only flash the pieces that
%have valid moves; to be tested
