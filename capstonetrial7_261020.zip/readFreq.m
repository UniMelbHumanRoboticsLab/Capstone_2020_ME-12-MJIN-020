%Note: Use this together with fft_teensy.ino
function freq=readFreq(a)
% delete(instrfindall);
tic
% Creat Bluetooth object
% a=Bluetooth('HC-06',1);

a.Timeout = 4000;
fopen(a);
toc 

% you can start pushing the button after the Elapsed Time shows up
startFFT = fscanf(a,'%s');
flushinput(a); 
startFFT = str2double(startFFT);

if startFFT == 1
    disp('testing ')
%   flushinput(a); 
    fprintf(a,'%c','2'); %send command to do FFT
    pause(2);            %wait to compute
    sSerialData = fscanf(a,'%s'); %get frequency
    flushinput(a);
    freq = str2double(sSerialData);
end
fclose(a);
end
