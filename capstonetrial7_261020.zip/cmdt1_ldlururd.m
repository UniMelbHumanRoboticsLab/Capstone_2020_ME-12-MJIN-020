%cmd_t1: LD,LU,RU,RD

%Left,Down (while loop: (-i, -i))
r = pieces(i).location(1) - 1;
c = pieces(i).location(2) - 1;
allyPieceHere = 0;
enemyPieceHere = 0;
while ((r>=1)&&(r<=8)&&(c>=1)&&(c<=8))
    %check each piece to see if any allies are atop
    for j=1:1:length(pieces)
        if (pieces(j).player==p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
            %Ally piece is here already
            allyPieceHere = 1;
            break
        end
    end
    if (allyPieceHere==0)
        %Check if this location has enemy piece here
        for j=1:1:length(pieces)
            if (pieces(j).player~=p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                %This enemy piece is here
                enemyPieceHere = 1;

                %Now can stop searching pieces[] array
                break
            end
        end

        %Location is either blank or has enemy piece
        %here. So set my piece to this location r and c
        %while checking for if this move will endanger
        %my king
        r_old = pieces(i).location(1);
        c_old = pieces(i).location(2);
        pieces(i).location(1) = r;
        pieces(i).location(2) = c;
        if (enemyPieceHere==1)
            pieces(j).status = 'dead';
            pieces(j).location(1) = 0;
            pieces(j).location(2) = 0;
        end
        inCheck = 0;
        checkKingDanger

        %Reset the piece's location after testing
        pieces(i).location(1) = r_old;
        pieces(i).location(2) = c_old;
        if (enemyPieceHere==1)
            pieces(j).status = 'alive';
            pieces(j).location(1) = r;
            pieces(j).location(2) = c;
        end

        if (inCheck==0)
            %Set variable to say there is a valid move
            %found
            noValidMove = 0;

            %Set checkmate=0
            inCheckmate = 0;

            %Break the while loop
            break
        end

        if (enemyPieceHere==1)
            %Enemy piece is here: cannot move any further left
            break;
        end

    else
        %Ally piece is here: cannot move any further left
        break;
    end

    %Go left,down again and repeat
    r=r-1;
    c=c-1;
    allyPieceHere = 0;
    enemyPieceHere = 0;
end

if (noValidMove==1)
    %Left,Up (while loop: (-i, +i))
    r = pieces(i).location(1) - 1;
    c = pieces(i).location(2) + 1;
    allyPieceHere = 0;
    enemyPieceHere = 0;
    while ((r>=1)&&(r<=8)&&(c>=1)&&(c<=8))
        %check each piece to see if any allies are atop
        for j=1:1:length(pieces)
            if (pieces(j).player==p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                %Ally piece is here already
                allyPieceHere = 1;
                break
            end
        end
        if (allyPieceHere==0)
            %Check if this location has enemy piece here
            for j=1:1:length(pieces)
                if (pieces(j).player~=p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                    %This enemy piece is here
                    enemyPieceHere = 1;

                    %Now can stop searching pieces[] array
                    break
                end
            end

            %Location is either blank or has enemy piece
            %here. So set my piece to this location r and c
            %while checking for if this move will endanger
            %my king
            r_old = pieces(i).location(1);
            c_old = pieces(i).location(2);
            pieces(i).location(1) = r;
            pieces(i).location(2) = c;
            if (enemyPieceHere==1)
                pieces(j).status = 'dead';
                pieces(j).location(1) = 0;
                pieces(j).location(2) = 0;
            end
            inCheck = 0;
            checkKingDanger

            %Reset the piece's location after testing
            pieces(i).location(1) = r_old;
            pieces(i).location(2) = c_old;
            if (enemyPieceHere==1)
                pieces(j).status = 'alive';
                pieces(j).location(1) = r;
                pieces(j).location(2) = c;
            end

            if (inCheck==0)
                %Set variable to say there is a valid move
                %found
                noValidMove = 0;

                %Set checkmate=0
                inCheckmate = 0;

                %Break the while loop
                break
            end

            if (enemyPieceHere==1)
                %Enemy piece is here: cannot move any further left
                break;
            end

        else
            %Ally piece is here: cannot move any further left
            break;
        end

        %Go left,up again and repeat
        r=r+1;
        c=c-1;
        allyPieceHere = 0;
        enemyPieceHere = 0;
    end
end
if (noValidMove==1)
    %Right,Up (while loop: (+i, +i))
    r = pieces(i).location(1) + 1;
    c = pieces(i).location(2) + 1;
    allyPieceHere = 0;
    enemyPieceHere = 0;
    while ((r>=1)&&(r<=8)&&(c>=1)&&(c<=8))
        %check each piece to see if any allies are atop
        for j=1:1:length(pieces)
            if (pieces(j).player==p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                %Ally piece is here already
                allyPieceHere = 1;
                break
            end
        end
        if (allyPieceHere==0)
            %Check if this location has enemy piece here
            for j=1:1:length(pieces)
                if (pieces(j).player~=p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                    %This enemy piece is here
                    enemyPieceHere = 1;

                    %Now can stop searching pieces[] array
                    break
                end
            end

            %Location is either blank or has enemy piece
            %here. So set my piece to this location r and c
            %while checking for if this move will endanger
            %my king
            r_old = pieces(i).location(1);
            c_old = pieces(i).location(2);
            pieces(i).location(1) = r;
            pieces(i).location(2) = c;
            if (enemyPieceHere==1)
                pieces(j).status = 'dead';
                pieces(j).location(1) = 0;
                pieces(j).location(2) = 0;
            end
            inCheck = 0;
            checkKingDanger

            %Reset the piece's location after testing
            pieces(i).location(1) = r_old;
            pieces(i).location(2) = c_old;
            if (enemyPieceHere==1)
                pieces(j).status = 'alive';
                pieces(j).location(1) = r;
                pieces(j).location(2) = c;
            end

            if (inCheck==0)
                %Set variable to say there is a valid move
                %found
                noValidMove = 0;

                %Set checkmate=0
                inCheckmate = 0;

                %Break the while loop
                break
            end

            if (enemyPieceHere==1)
                %Enemy piece is here: cannot move any further left
                break;
            end

        else
            %Ally piece is here: cannot move any further left
            break;
        end

        %Go right,up again and repeat
        r=r+1;
        c=c+1;
        allyPieceHere = 0;
        enemyPieceHere = 0;
    end
end
if (noValidMove==1)
    %Right,Down (while loop: (+i, -i))
    r = pieces(i).location(1) - 1;
    c = pieces(i).location(2) + 1;
    allyPieceHere = 0;
    enemyPieceHere = 0;
    while ((r>=1)&&(r<=8)&&(c>=1)&&(c<=8))
        %check each piece to see if any allies are atop
        for j=1:1:length(pieces)
            if (pieces(j).player==p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                %Ally piece is here already
                allyPieceHere = 1;
                break
            end
        end
        if (allyPieceHere==0)
            %Check if this location has enemy piece here
            for j=1:1:length(pieces)
                if (pieces(j).player~=p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                    %This enemy piece is here
                    enemyPieceHere = 1;

                    %Now can stop searching pieces[] array
                    break
                end
            end

            %Location is either blank or has enemy piece
            %here. So set my piece to this location r and c
            %while checking for if this move will endanger
            %my king
            r_old = pieces(i).location(1);
            c_old = pieces(i).location(2);
            pieces(i).location(1) = r;
            pieces(i).location(2) = c;
            if (enemyPieceHere==1)
                pieces(j).status = 'dead';
                pieces(j).location(1) = 0;
                pieces(j).location(2) = 0;
            end
            inCheck = 0;
            checkKingDanger

            %Reset the piece's location after testing
            pieces(i).location(1) = r_old;
            pieces(i).location(2) = c_old;
            if (enemyPieceHere==1)
                pieces(j).status = 'alive';
                pieces(j).location(1) = r;
                pieces(j).location(2) = c;
            end

            if (inCheck==0)
                %Set variable to say there is a valid move
                %found
                noValidMove = 0;

                %Set checkmate=0
                inCheckmate = 0;

                %Break the while loop
                break
            end

            if (enemyPieceHere==1)
                %Enemy piece is here: cannot move any further left
                break;
            end

        else
            %Ally piece is here: cannot move any further left
            break;
        end

        %Go right,down again and repeat
        r=r-1;
        c=c+1;
        allyPieceHere = 0;
        enemyPieceHere = 0;
    end
end