% Capstone Project 2020: Brain-Controlled Chess Playing Robot with Steady-State Visual Evoked Potential

%Written by: Al Bryan Bentillo
%Institution: The University of Melbourne

% Description: This file runs the SSVEP Emulation function of the AHS. Use
% it in conjunction with 'fft_teensy.ino' to acquire the visual stimulus
% frequency. The frequency will be used as an input to the brain model to
% create the artificial SSVEP. 
%
% Other brain model parameters such as noise power input can be adjusted in
% this file under the 'Lumped Alpha Rhythm Model Parameters' and 'Noise
% Power Input' section. Take note that other parameters for the sigmoid
% functions are adjusted in the Simulink blocks 'excitatory sigmoid
% function' and 'inhibitory sigmoid function'.
%
% Finally, this file also runs the Simulink file automatically under the
% 'Run Simulink Model' section. To check the FFT and power spectrum of the
% artificial SSVEP, use the 'fft_model.m' after running the Simulink file. 

clear
clc

%% Set up Bluetooth Module and Acquire Fundamental Frequency
delete(instrfindall);
tic
a=Bluetooth('HC-06',1);

a.Timeout = 40;
fopen(a);
toc 

% Note: you can start pushing the button after the Elapsed Time shows up in
% MATLAB command window. 
startFFT = fscanf(a,'%s');
flushinput(a); 
startFFT = str2double(startFFT);

% loop to acquire the fundamental frequency of visual stimulus
if startFFT == 1
    fprintf(a,'%c','2'); %send command to do FFT
    pause(1);            %wait to compute
    sSerialData = fscanf(a,'%s'); %get frequency
    flushinput(a); 
    freq = str2double(sSerialData); 
end
fclose(a);

%% Brain Model Input Frequency and Sampling Rate
f_in = freq; % input freq in hertz 18 Hz --> maximum freq
Fs = 1000; %sampling freq

%% For Square Wave Input
% This section sets the input frequency of the brain model in case a Square
% Wave input is used. Take note that the choice of having a sine/square 
% input is manually adjusted on the Simulink file.

f_sq = round(Fs/f_in,0); %period

if rem(f_sq, 2) ~= 0
    f_sq = f_sq + 1;
end

pw = f_sq/2; % Pulse Width

%% Lumped Alpha Rhythm Model Parameters
A = 1.65;
B = 32;
C1 = 32;
C2 = 3;
a1 = 55;
a2 = 605;
b1 = 27.5;
b2 = 55;

G = 120; %amplitude or max firing rate (pps)

%% Noise Power Input
NSP = 100; % Adjust this depending on your desired noise power

%% Run Simulink Model
Simulation_Time = 6;
sim('brainmodel',Simulation_Time)
