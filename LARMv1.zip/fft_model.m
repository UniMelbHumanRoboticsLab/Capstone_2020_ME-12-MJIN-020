% Capstone Project 2020: Brain-Controlled Chess Playing Robot with Steady-State Visual Evoked Potential

%Written by: Al Bryan Bentillo
%Institution: The University of Melbourne

% Description: This code is used to create plots of the Amplitude and Power
% Spectrum of the Artificial SSVEP. Run this code after the Simulink model
% has finished to see the aformentioned plots.

clc

%% Acquire Time-Domain Plot from Simulink
% start at 0.5s and end at 5.5s same as Benchmark database method
time = out.simout.time(501:5500);
amp = out.simout.Data(501:5500);
                 
T = 1/Fs;             % Sampling period from 'brainmodel_params.m'     

%% Normalize Plots
ave = mean(amp);
X = amp - ave;

%% Discrete Fast Fourier Transform
n = 2^nextpow2(length(X)); %Change input length of signal to improve fft performance 
ff = fft(X,n); %Do fast fourier transform

%% Remove mirror image result from fft
f = Fs*(0:(n/2))/n;
P = abs(ff)/n;

%% Plot Amplitude Spectrum
subplot(3,1,1)
plot(f,P(1:n/2+1)) 
title('Frequency Domain Plot of Emulated SSVEP using FFT')
xlabel('Frequency (f)')
ylabel('mV');
grid on

%% Plot Power Spectrum 
subplot(3,1,2)
[Pxx,F] = periodogram(X,[],length(X),Fs);
plot(F,10*log10(Pxx))
grid on
xlabel('Frequency(Hz)');
ylabel('dB');
% ylim([-50 50])
title('Power Spectra of Emulated SSVEP');

%% Signal-to-Noise Ratio
% Use narrow-band SNR calculation to calculate SNR Power Spectrum for each frequency
% iteration

SNR_nar = zeros(1,length(P)/2+1);
m = length(SNR_nar);
for i=1:m
    if i<6
        switch i
            case 1
                SNR_nar(i) = 20*log10(P(i)/sum(P(i+1:i+10)));
            case 2
                SNR_nar(i) = 20*log10(P(i)/(P(i-1,1)+sum(P(i+1:i+9))));
            case 3
                SNR_nar(i) = 20*log10(P(i)/(P(i-1,1)+P(i-2,1)+sum(P(i+1:i+8))));
            case 4
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i-3:i-1))+sum(P(i+1:i+7))));
            case 5
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i-4:i-1))+sum(P(i+1:i+6))));
        end
    elseif i > m-6
        switch i
            case m
                SNR_nar(i) = 20*log10(P(i)/sum(P(i-1:i-10)));
            case m-1
                SNR_nar(i) = 20*log10(P(i)/(P(i+1,1)+sum(P(i-1:i-9))));
            case m-2
                SNR_nar(i) = 20*log10(P(i)/(P(i+1,1)+P(i+2,1)+sum(P(i-1:i-8))));
            case m-3
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i+3:i+1))+sum(P(i-1:i-7))));
            case m-4
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i+4:i+1))+sum(P(i-1:i-6))));
        end
    else
        SNR_nar(i) = 20*log10(P(i)/(sum(P(i-5:i-1))+sum(P(i+1:i+5)))); 
    end
end

subplot(3,1,3)

plot(f,SNR_nar) 
grid on
xlabel('Frequency(Hz)');
ylabel('(SNR)dB');
% ylim([-50 50])
title('Power Spectra of Emulated SSVEP SNR');
