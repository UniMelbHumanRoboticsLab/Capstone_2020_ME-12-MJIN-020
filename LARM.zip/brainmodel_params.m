clc
clear

f_in = 15; % input freq in hertz 18 Hz --> max freq
Fs = 1000; %sampling freq

%% For Square Wave Input
f_sq = round(1000/f_in,0); %period

if rem(f_sq, 2) ~= 0
    f_sq = f_sq + 1;
end

pw = f_sq/2; % Pulse Width


%% Lumped Alpha Rhythm Model Parameters
A = 1.65;
B = 32;
C1 = 32;
C2 = 3;
a1 = 55;
a2 = 605;
b1 = 27.5;
b2 = 55;

G = 120; %amplitude or max firing rate (pps)
% theta = -54; %mV

%% Noise Power Input
NSP = 100; % from Nonlinear Origin of SSVEP Spectra
