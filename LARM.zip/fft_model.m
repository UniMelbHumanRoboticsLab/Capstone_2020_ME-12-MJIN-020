clc

%% Parameters
% start at 0.5s and end at 5.5s same as Benchmark database method
time = out.simout.time(501:5500);
amp = out.simout.Data(501:5500);
                 
T = 1/Fs;             % Sampling period      

%% Show Plot
% plot(time,amp);
% hold on
%Normalize Data
% X = 2*(amp-min(amp))/(max(amp)-min(amp))-1;
% plot(time,X);
ave = mean(amp);
X = amp - ave;
% plot(time,X);

%% Discrete Fast Fourier Transform
n = 2^nextpow2(length(X)); %Change input length of signal to improve fft performance 
ff = fft(X,n); %Do fast fourier transform

%% remove mirror image result from fft
f = Fs*(0:(n/2))/n;
P = abs(ff)/n;
%% Plot
subplot(3,1,1)
plot(f,P(1:n/2+1)) 
title('Frequency Domain Plot of Emulated SSVEP using FFT')
xlabel('Frequency (f)')
ylabel('mV');
grid on

%% Power Spectrum
% psd = abs(fft(X).^2);

subplot(3,1,2)
% plot(f,psd(1:n/2+1))
[Pxx,F] = periodogram(X,[],length(X),Fs);
plot(F,10*log10(Pxx))
grid on
xlabel('Frequency(Hz)');
ylabel('dB');
% ylim([-50 50])
title('Power Spectra of Emulated SSVEP');

%% Signal-to-Noise Ratio
% Use narrow-band SNR calculation to calculate SNR for each
SNR_nar = zeros(1,length(P)/2+1);
m = length(SNR_nar);
for i=1:m
    if i<6
        switch i
            case 1
                SNR_nar(i) = 20*log10(P(i)/sum(P(i+1:i+10)));
            case 2
                SNR_nar(i) = 20*log10(P(i)/(P(i-1,1)+sum(P(i+1:i+9))));
            case 3
                SNR_nar(i) = 20*log10(P(i)/(P(i-1,1)+P(i-2,1)+sum(P(i+1:i+8))));
            case 4
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i-3:i-1))+sum(P(i+1:i+7))));
            case 5
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i-4:i-1))+sum(P(i+1:i+6))));
        end
    elseif i > m-6
        switch i
            case m
                SNR_nar(i) = 20*log10(P(i)/sum(P(i-1:i-10)));
            case m-1
                SNR_nar(i) = 20*log10(P(i)/(P(i+1,1)+sum(P(i-1:i-9))));
            case m-2
                SNR_nar(i) = 20*log10(P(i)/(P(i+1,1)+P(i+2,1)+sum(P(i-1:i-8))));
            case m-3
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i+3:i+1))+sum(P(i-1:i-7))));
            case m-4
                SNR_nar(i) = 20*log10(P(i)/(sum(P(i+4:i+1))+sum(P(i-1:i-6))));
        end
    else
        SNR_nar(i) = 20*log10(P(i)/(sum(P(i-5:i-1))+sum(P(i+1:i+5)))); 
    end
end

subplot(3,1,3)

plot(f,SNR_nar) 
grid on
xlabel('Frequency(Hz)');
ylabel('(SNR)dB');
% ylim([-50 50])
title('Power Spectra of Emulated SSVEP');

%% Compute Noise Power 
pRMS = rms(amp)^2
% Sig_pow = (sum(amp)^2)/length(amp);
Noise_pow = pRMS/1.8279
