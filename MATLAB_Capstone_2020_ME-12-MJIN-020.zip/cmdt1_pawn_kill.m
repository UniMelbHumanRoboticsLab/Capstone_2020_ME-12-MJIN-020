% Capstone Project 2020: Brain-Controlled Chess Playing Robot with Steady-State Visual Evoked Potential

%Written by: Sean Cs Ly
%Institution: The University of Melbourne

%cmdt1_pawn_kill

if ((r>=1)&&(r<=8)&&(c>=1)&&(c<=8))
    %check each piece to see if any allies are atop
    for j=1:1:length(pieces)
        if (pieces(j).player==p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
            %Ally piece is here already
            allyPieceHere = 1;
            break
        end
    end
    if (allyPieceHere==0)
        %Check if this location has enemy piece here
        for j=1:1:length(pieces)
            if (pieces(j).player~=p_turn)&&(pieces(j).location(1)==r)&&(pieces(j).location(2)==c)
                %This enemy piece is here
                enemyPieceHere = 1;

                %Now can stop searching pieces[] array
                break
            end
        end

        if (enemyPieceHere==1)
            %Location has enemy, so set my piece to this location r and c
            %while checking for if this move will endanger
            %my king
            r_old = pieces(i).location(1);
            c_old = pieces(i).location(2);
            pieces(i).location(1) = r;
            pieces(i).location(2) = c;
            if (enemyPieceHere==1)
                pieces(j).status = 'dead';
                pieces(j).location(1) = 0;
                pieces(j).location(2) = 0;
            end
            inCheck = 0;
            checkKingDanger

            %Reset the piece's location after testing
            pieces(i).location(1) = r_old;
            pieces(i).location(2) = c_old;
            if (enemyPieceHere==1)
                pieces(j).status = 'alive';
                pieces(j).location(1) = r;
                pieces(j).location(2) = c;
            end

            if (inCheck==0)
                %Set variable to say there is a valid move
                %found
                noValidMove = 0;

                %Set checkmate=0
                inCheckmate = 0;
            end
        end
    end
end