% Capstone Project 2020: Brain-Controlled Chess Playing Robot with Steady-State Visual Evoked Potential

%Written by: Sean Cs Ly
%Institution: The University of Melbourne

%checkKingDanger
%Check for king endangerment

%Location is either blank or has enemy piece
%here. So set my piece to this location r and c
%while checking for if this move will endanger
%my king

for j=1:1:length(pieces)
    if (pieces(j).player~=p_turn)&&(strcmp(pieces(j).status, 'alive')==1)
        %Enemy piece that is alive: check if it can kill my king
        if (strcmp(pieces(j).piecetype, 'rook')==1)||(strcmp(pieces(j).piecetype, 'rookP')==1)
            %Left
            r2 = pieces(j).location(1);
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                c2 = c2-1;
            end
            %Right
            r2 = pieces(j).location(1);
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                c2 = c2+1;
            end
            %Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2);
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
            end
            %Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2);
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
            end
        elseif (strcmp(pieces(j).piecetype, 'knight')==1)||(strcmp(pieces(j).piecetype, 'knightP')==1) %Knight
            %(-2,-1)
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) - 2;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end

            %(-2,+1)
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) - 2;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(+2,+1)
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) + 2;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(+2,-1)
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) + 2;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(-1,-2)
            r2 = pieces(j).location(1) - 2;
            c2 = pieces(j).location(2) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(-1,+2)
            r2 = pieces(j).location(1) + 2;
            c2 = pieces(j).location(2) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(+1,+2)
            r2 = pieces(j).location(1) + 2;
            c2 = pieces(j).location(2) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %(+1,-2)
            r2 = pieces(j).location(1) - 2;
            c2 = pieces(j).location(2) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
        elseif (strcmp(pieces(j).piecetype, 'bishop')==1)||(strcmp(pieces(j).piecetype, 'bishopP')==1) %Bishop                   
            %Left,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
                c2 = c2-1;
            end
            %Left,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
                c2 = c2-1;
            end
            %Right,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
                c2 = c2+1;
            end
            %Right,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
                c2 = c2+1;
            end
        elseif (strcmp(pieces(j).piecetype, 'queen')==1)||(strcmp(pieces(j).piecetype, 'queenP')==1) %Queen                    
            %Left
            r2 = pieces(j).location(1);
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                c2 = c2-1;
            end
            %Right
            r2 = pieces(j).location(1);
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                c2 = c2+1;
            end
            %Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2);
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
            end
            %Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2);
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
            end
            %Left,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
                c2 = c2-1;
            end
            %Left,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) - 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
                c2 = c2-1;
            end
            %Right,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2+1;
                c2 = c2+1;
            end
            %Right,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) + 1;
            pieceHere = 0;
            while ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if they are on this location
                for k=1:1:length(pieces)                            
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        %piece is here
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %King is in danger
                            inCheck=1;
                        end
                        pieceHere=1;
                        break
                    end
                end
                if (pieceHere==1)
                    break
                end
                r2 = r2-1;
                c2 = c2+1;
            end
        elseif (strcmp(pieces(j).piecetype, 'king')==1) %King
            %Left
            c2 = pieces(j).location(2) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Right
            c2 = pieces(j).location(2) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Down
            r2 = pieces(j).location(1) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Up
            r2 = pieces(j).location(1) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Left,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Left,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) - 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Right,Up
            r2 = pieces(j).location(1) + 1;
            c2 = pieces(j).location(2) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
            %Right,Down
            r2 = pieces(j).location(1) - 1;
            c2 = pieces(j).location(2) + 1;
            if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                %check each piece to see if any pieces are atop
                for k=1:1:length(pieces)
                    if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                        if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                            %This enemy piece can kill the king
                            inCheck=1;
                        end
                        break
                    end
                end
            end
        else %Pawn
            if (p_turn==1)
                %Left kill
                r2 = pieces(j).location(1) - 1;
                c2 = pieces(j).location(2) + 1;
                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                    %check each piece to see if any pieces are atop
                    for k=1:1:length(pieces)
                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                                %This enemy piece can kill the king
                                inCheck=1;
                            end
                            break
                        end
                    end
                end
                %Right kill
                r2 = pieces(j).location(1) - 1;
                c2 = pieces(j).location(2) - 1;
                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                    %check each piece to see if any pieces are atop
                    for k=1:1:length(pieces)
                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                                %This enemy piece can kill the king
                                inCheck=1;
                            end
                            break
                        end
                    end
                end
            else
                %Left kill
                r2 = pieces(j).location(1) + 1;
                c2 = pieces(j).location(2) - 1;
                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                    %check each piece to see if any pieces are atop
                    for k=1:1:length(pieces)
                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                                %This enemy piece can kill the king
                                inCheck=1;
                            end
                            break
                        end
                    end
                end
                %Right kill
                r2 = pieces(j).location(1) + 1;
                c2 = pieces(j).location(2) + 1;
                if ((r2>=1)&&(r2<=8)&&(c2>=1)&&(c2<=8))
                    %check each piece to see if any pieces are atop
                    for k=1:1:length(pieces)
                        if (pieces(k).location(1)==r2)&&(pieces(k).location(2)==c2)
                            if (pieces(k).player==p_turn)&&(strcmp(pieces(k).piecetype, 'king')==1)
                                %This enemy piece can kill the king
                                inCheck=1;
                            end
                            break
                        end
                    end
                end
            end
        end
    end
end